import difflib
import sys
from pathlib import PurePosixPath
from urllib.parse import unquote, urlparse

from git import Repo

import httpx
from wasabi import color

from honeybadger.config import Config
from honeybadger.oai import BugFixer

config = Config()


def update_pr(pr_info, file, suggested_changes):
    owner = pr_info["owner"]
    repo = pr_info["repo"]
    pull = pr_info["pull"]
    commit_id = pr_info["commit_id"]
    review_url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull}/comments"
    feedback = (
        "Hello from CircleCI,\n\n"
        "This change failed your build here is our suggestion to fix it:\n"
        "```suggestion\n"
        f"{suggested_changes}\n"
        "```"
    )

    payload = {
        "body": feedback,
        "path": file,
        "subject_type": "file",
        "commit_id": commit_id,
    }
    resp = httpx.post(
        review_url,
        json=payload,
        headers={"Authorization": f"Bearer {config.GH_TOKEN}"},
    )

    if resp.status_code == 422:
        print(
            "Could not update the PR with a review comment. Is the file to repair included in the PR?"
        )
        return
    resp.raise_for_status()


def hydrate_job_by_build_num(slug, job_num):
    url = f"https://circleci.com/api/v1.1/project/{slug}/{job_num}"
    headers = {"Circle-Token": f"{config.CIRCLE_TOKEN}"}

    response = httpx.get(url, headers=headers)
    response.raise_for_status()

    return response.json()


def get_failed_steps_output(job):
    """Finds failed steps in a job and returns the output_urls for the failed steps."""
    failed_step_output_urls = []
    for step in job["steps"]:
        _step = step["actions"][0]
        if _step["status"] == "failed":
            failed_step_output_urls.append(_step["output_url"])
    return failed_step_output_urls


def download_output(url):
    """Download the output from CircleCI's API for the step output URL"""
    headers = {"Circle-Token": f"{config.CIRCLE_TOKEN}"}
    response = httpx.get(url, headers=headers)
    response.raise_for_status()
    output = response.json()
    return output[0]["message"]


def using_cci(build_url):
    # https://app.circleci.com/pipelines/github/michael-webster/cody-demo/15/workflows/aacb0616-bfdb-42e8-b284-0eb97e92bcd6/jobs/55
    url_path = unquote(urlparse(build_url).path)
    path = PurePosixPath(url_path)
    org = path.parts[3]
    project = path.parts[4]
    build_num = path.parts[9]

    job = hydrate_job_by_build_num(f"gh/{org}/{project}", build_num)
    failed_output_url = get_failed_steps_output(job)[0]
    logs = download_output(failed_output_url)
    prs = job["pull_requests"]
    pr_info = None
    if prs:
        print("adding pull request comment")
        update_url = prs[0]["url"]
        url_path = unquote(urlparse(update_url).path)
        path = PurePosixPath(url_path)
        owner = path.parts[1]
        repo = path.parts[2]
        pull = path.parts[4]
        pr_info = {
            "owner": owner,
            "repo": repo,
            "pull": pull,
            "commit_id": job["vcs_revision"],
        }
    else:
        raise Exception("no pull request found")
    return logs, pr_info


def format_diff(a, b):
    output = []
    matcher = difflib.SequenceMatcher(None, a, b)
    for opcode, a0, a1, b0, b1 in matcher.get_opcodes():
        if opcode == "equal":
            output.append(a[a0:a1])
        elif opcode == "insert":
            output.append(color(b[b0:b1], fg=16, bg="green"))
        elif opcode == "delete":
            output.append(color(a[a0:a1], fg=16, bg="red"))
        elif opcode == "replace":
            output.append(color(b[b0:b1], fg=16, bg="green"))
            output.append(color(a[a0:a1], fg=16, bg="red"))
    return "".join(output)


def fix_bugs(changes, log_output):
    bug_fixer = BugFixer(config.OPENAI_ORG, config.OPENAI_API_KEY)
    ai_suggestion = bug_fixer.fix_bugs(log_output, changes)
    return ai_suggestion


def fixit(output_path, change_path):
    with open(change_path, "r+", encoding="utf8") as code, open(
        output_path, "r", encoding="utf8"
    ) as output:
        print("Trying to fix your bugs")
        changes = code.read()
        logs = output.read()
        print(f"fixing changes for: {change_path}")
        suggestions = fix_bugs(changes, logs)
        print(
            f"the AI suggested the following changes, will overwrite your file: {suggestions}"
        )
        code.seek(0)
        code.write(suggestions)


def main():
    output_path = sys.argv[1]
    change_path = sys.argv[2]
    fixit(output_path, change_path)


# main()
