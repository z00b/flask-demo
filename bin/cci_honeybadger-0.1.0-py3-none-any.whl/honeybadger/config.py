import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    HTTP_PORT = int(os.environ.get("HTTP_PORT", "8080"))
    CIRCLE_TOKEN = os.environ.get("CIRCLE_TOKEN")
    CIRCLE_WEBHOOK_SECRET = os.environ.get("CIRCLE_WEBHOOK_SECRET")
    GH_TOKEN = os.environ.get("GH_TOKEN")
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
    OPENAI_ORG = os.environ.get("OPENAI_ORG", "org-obAH84J2bpuzhbMLDG7UmD3A")

    OPENAI_MODEL = "gpt-3.5-turbo-16k"
    OPENAI_MAX_TOKENS = 777

    # For confidence and predictability, we want temperature to be extremely deterministic (i.e ICE COLD!)
    TEMPERATURE = 0.0

    SUPPORTED_LANGUAGES = {
        "JavaScript": {
            "supported_file_types": [
                ".js",
                ".jsx",
                ".json",
                ".ts",
                ".tsx",
            ]
        },
        "TypeScript": {
            "supported_file_types": [
                ".js",
                ".jsx",
                ".json",
                ".ts",
                ".tsx",
            ]
        },
        "Python": {"supported_file_types": [".py"]},
        "Java": {"supported_file_types": [".java"]},
        "C++": {"supported_file_types": [".cpp", ".h"]},
    }
