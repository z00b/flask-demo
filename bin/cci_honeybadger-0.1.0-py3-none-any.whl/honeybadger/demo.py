import gradio as gr
import os
from honeybadger.config import Config
from honeybadger.oai import BugFixer, ErrorSummarizer
from wasabi import color
import difflib


def gradio_demo():
    block = gr.Blocks()

    with block:
        gr.Markdown("<h3><center>CircleCI Error Summarizer</center></h3>")
        gr.Markdown(
            """
        Enter Open AI and CircleCI API keys.

        Then, enter a project slug and pipeline.

        We'll retrieve the build output and summarize what went wrong.
        """
        )

        with gr.Row():
            errorText = gr.TextArea(
                label="Build Error", placeholder="Enter your failure message"
            )
            codeChanges = gr.TextArea(
                label="Change", placeholder="Enter the changes you made"
            )

        reason = gr.TextArea(label="Explanation of build error", interactive=False)
        change = gr.TextArea(label="Suggested fix", interactive=False)

    block.launch()


def format_diff(a, b):
    output = []
    matcher = difflib.SequenceMatcher(None, a, b)
    for opcode, a0, a1, b0, b1 in matcher.get_opcodes():
        if opcode == "equal":
            output.append(a[a0:a1])
        elif opcode == "insert":
            output.append(color(b[b0:b1], fg=16, bg="green"))
        elif opcode == "delete":
            output.append(color(a[a0:a1], fg=16, bg="red"))
        elif opcode == "replace":
            output.append(color(b[b0:b1], fg=16, bg="green"))
            output.append(color(a[a0:a1], fg=16, bg="red"))
    return "".join(output)


def bugfix_demo():
    with open(
        "./data/build-failures/code_changes.txt", "r", encoding="utf-8"
    ) as code, open(
        "./data/build-failures/log_output.txt", "r", encoding="utf-8"
    ) as logs:
        code_changes = code.read()
        log_output = logs.read()
        config = Config()
        bug_fixer = BugFixer(config.OPENAI_ORG, config.OPENAI_API_KEY)
        ai_suggestion = bug_fixer.fix_bugs(log_output, code_changes)
        print(format_diff(code_changes, ai_suggestion))


def explainer_demo():
    with open(
        "./data/build-failures/code_changes.txt", "r", encoding="utf-8"
    ) as code, open(
        "./data/build-failures/log_output.txt", "r", encoding="utf-8"
    ) as logs:
        code_changes = code.read()
        log_output = logs.read()
        config = Config()
        error_summarizer = ErrorSummarizer(config.OPENAI_ORG, config.OPENAI_API_KEY)
        ai_suggestion = error_summarizer.generate_error_summary(log_output)
        print(ai_suggestion)


bugfix_demo()
print("now running the explainer...")
explainer_demo()
