import hmac
import os
import typing
from pathlib import PurePosixPath
from urllib.parse import unquote, urlparse

import httpx
from dotenv import load_dotenv
from fastapi import BackgroundTasks, FastAPI, Request

from honeybadger import oai
from honeybadger.config import Config

load_dotenv()

config = Config()

summarizer = oai.ErrorSummarizer(config.OPENAI_ORG, config.OPENAI_API_KEY)
app = FastAPI()


def hydrate_job_by_build_num(slug, job_num):
    url = f"https://circleci.com/api/v1.1/project/{slug}/{job_num}"
    headers = {"Circle-Token": f"{config.CIRCLE_TOKEN}"}

    response = httpx.get(url, headers=headers)
    response.raise_for_status()

    return response.json()


def get_failed_steps_output(job):
    """Finds failed steps in a job and returns the output_urls for the failed steps."""
    failed_step_output_urls = []
    for step in job["steps"]:
        _step = step["actions"][0]
        if _step["status"] == "failed":
            failed_step_output_urls.append(_step["output_url"])
    return failed_step_output_urls


def download_output(url):
    """Download the output from CircleCI's API for the step output URL"""
    headers = {"Circle-Token": f"{config.CIRCLE_TOKEN}"}
    response = httpx.get(url, headers=headers)
    response.raise_for_status()
    output = response.json()
    return output[0]["message"]


def handle_circle_hook(event: typing.Any):
    """Receive a CircleCI webhook and summarize errors if it is for a failed job"""
    project = event["project"]
    slug = project["slug"]
    job = event["job"]
    full_job = hydrate_job_by_build_num(slug, job["number"])
    job_url = full_job["build_url"]
    failed_output_urls = get_failed_steps_output(full_job)
    output = "\n".join(download_output(failed_output_urls[0]).split("\n")[-200:])
    summary = summarizer.generate_error_summary(output)
    prs = full_job["pull_requests"]
    if prs:
        print("adding pull request comment")
        update_url = prs[0]["url"]
        url_path = unquote(urlparse(update_url).path)
        path = PurePosixPath(url_path)
        owner = path.parts[1]
        repo = path.parts[2]
        pull = path.parts[4]
        review_url = f"https://api.github.com/repos/{owner}/{repo}/pulls/{pull}/reviews"
        comment = (
            "Hello from CircleCI,\n\n"
            "We noticed you had some errors running this build. Here is our best guess at the issue...\n\n"
            f"{summary}\n\n"
            f"To see the full error, checkout: {job_url}"
        )
        resp = httpx.post(
            review_url,
            json={"body": comment, "event": "COMMENT"},
            headers={"Authorization": f"Bearer {config.GH_TOKEN}"},
        )
        resp.raise_for_status()
    else:
        print("No PR associated with this change, skipping it")


def _validate_circle_signature(secret, body, signature):
    body_digest = hmac.new(bytes(secret, "utf-8"), body, "sha256").hexdigest()
    if not signature:
        raise ValueError("circleci-signature header is missing")
    if not hmac.compare_digest(signature, f"v1={body_digest}"):
        raise ValueError("circleci-signature header is invalid")


@app.post("/webhook")
async def handle_webhook(payload: Request, background_tasks: BackgroundTasks):
    body = await payload.body()
    signatures = payload.headers.get("circleci-signature").split(",")
    if not signatures or len(signatures) == 0:
        raise ValueError("circleci-signature header is missing")

    try:
        _validate_circle_signature(config.CIRCLE_WEBHOOK_SECRET, body, signatures[0])
    except ValueError as ex:
        raise ValueError("error validating signature") from ex

    event = await payload.json()
    background_tasks.add_task(handle_circle_hook, event)

    # Handle the webhook event and data
    # Add your custom logic here

    return {"message": f"Received webhook event: {event}"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=config.HTTP_PORT)
