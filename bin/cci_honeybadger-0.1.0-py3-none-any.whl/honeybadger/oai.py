import json
import logging
import os
import sys

import tenacity

import openai
from honeybadger import prompts

logging.basicConfig(stream=sys.stderr, level=logging.ERROR)
logger = logging.getLogger(__name__)


class BugFixer:
    def __init__(self, openai_org, openai_api_key) -> None:
        openai.organization = openai_org
        openai.api_key = openai_api_key

        self.formatting_function = {
            "name": "format_output",
            "description": "Format the gpt output from json",
            "parameters": {
                "type": "object",
                "properties": {
                    "error_summary": {
                        "type": "string",
                        "description": "The explanation for the bug. Infer this from the error message",
                    },
                    "code": {
                        "type": "string",
                        "description": "The rewritten file",
                    },
                },
                "required": ["error_summary", "code"],
            },
        }

    @tenacity.retry(
        stop=tenacity.stop_after_attempt(10),
        after=tenacity.after_log(logger, logging.ERROR),
    )
    def fix_bugs(self, build_output, changes):
        user_prompt = prompts.bug_fix_user_prompt.format(build_output, changes)
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-16k",
            functions=[self.formatting_function],
            function_call={"name": "format_output"},
            messages=[
                {
                    "role": "system",
                    "content": prompts.system_bug_fix_prompt,
                },
                {
                    "role": "user",
                    "content": user_prompt,
                },
            ],
        )
        return json.loads(
            response["choices"][0]["message"]["function_call"]["arguments"]
        )["code"]


class ErrorSummarizer:
    def __init__(self, openai_org, openai_api_key) -> None:
        openai.organization = openai_org
        openai.api_key = openai_api_key

    def generate_error_summary(self, build_output):
        user_prompt = build_output
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-16k",
            messages=[
                {
                    "role": "system",
                    "content": prompts.system_error_explanation,
                },
                {
                    "role": "user",
                    "content": user_prompt,
                },
            ],
        )
        return response["choices"][0]["message"]["content"]
