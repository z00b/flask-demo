system_error_explanation = """
Explain the error to the user. Be brief. Include code suggestions if they are applicable.
"""


with_diff_context = """
These are the code changes in the pull request:

```diff
{}
```

I think the problem is: {}

Please write code to fix these errors.
"""

system_bug_fix_prompt = """
Fix the code to based on the errors. Only update the code needed to fix the errors, output the rest of the file unchanged.
Summarize the error in 10 words or less and summarize the fix in 10 words or less.
"""

bug_fix_user_prompt = """

## Error
```
{}
```

## Code
```
{}
```
"""
